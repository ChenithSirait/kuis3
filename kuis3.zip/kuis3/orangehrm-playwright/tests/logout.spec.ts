import { test, expect } from '@playwright/test';
import { login } from '../helpers/helpers';

test('Logout berhasil', async ({ page }) => {
  await login(page);
  await page.getByRole('img', { name: 'profile picture' }).click();
  await page.getByText('Logout').click();
  await expect(page).toHaveURL(/auth\/login/);
  await page.screenshot({ path: 'screenshots/logout.png', fullPage: true });
});
