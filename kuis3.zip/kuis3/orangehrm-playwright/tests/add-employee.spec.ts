import { test, expect } from '@playwright/test';
import { login } from '../helpers/helpers';
import fs from 'fs';

// Buat folder screenshot jika belum ada
fs.mkdirSync('screenshots', { recursive: true });

test('Tambah karyawan baru', async ({ page }) => {
  await login(page);

  // Navigasi ke menu PIM
  await page.getByRole('link', { name: 'PIM' }).click();
  await page.waitForLoadState('networkidle');

  // Klik tombol Add Employee
  await page.getByRole('button', { name: 'Add' }).click();
  await expect(page.getByRole('heading', { name: 'Add Employee' })).toBeVisible();

  // Isi form nama
  await page.getByPlaceholder('First Name').fill('John');
  await page.getByPlaceholder('Last Name').fill('Doe');

  // Klik Save
  await page.getByRole('button', { name: 'Save' }).click();

  // Tunggu hingga tab "Personal Details" muncul untuk memastikan halaman sudah siap
  await page.getByRole('tab', { name: 'Personal Details' }).waitFor();

  // Verifikasi halaman detail personal
  await expect(page.getByRole('heading', { name: 'Personal Details' })).toBeVisible();

  // Screenshot
  await page.screenshot({ path: 'screenshots/add-employee.png', fullPage: true });
});
