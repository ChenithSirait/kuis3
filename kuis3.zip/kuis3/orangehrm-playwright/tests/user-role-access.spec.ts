import { test, expect } from '@playwright/test';
import { login } from '../helpers/helpers';

test('Lihat daftar user dan role-nya', async ({ page }) => {
  await login(page);
  await page.getByRole('link', { name: 'Admin' }).click();
  await expect(page.getByText('System Users')).toBeVisible();
  await page.screenshot({ path: 'screenshots/system-users.png', fullPage: true });
});
