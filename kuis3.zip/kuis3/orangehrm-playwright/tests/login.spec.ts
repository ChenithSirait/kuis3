import { test, expect } from '@playwright/test';

test('Login berhasil dengan kredensial valid', async ({ page }) => {
  await page.goto('/web/index.php/auth/login');
  await page.getByPlaceholder('Username').fill('Admin');
  await page.getByPlaceholder('Password').fill('admin123');
  await page.getByRole('button', { name: 'Login' }).click();

  await expect(page).toHaveURL(/dashboard/);
  await page.screenshot({ path: 'screenshots/login-success.png', fullPage: true });
});
