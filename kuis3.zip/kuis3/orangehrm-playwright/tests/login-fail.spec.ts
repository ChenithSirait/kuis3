import { test, expect } from '@playwright/test';

test('Login gagal karena password salah', async ({ page }) => {
  await page.goto('/web/index.php/auth/login');
  await page.getByPlaceholder('Username').fill('Admin');
  await page.getByPlaceholder('Password').fill('wrongpass');
  await page.getByRole('button', { name: 'Login' }).click();

  await expect(page.getByText('Invalid credentials')).toBeVisible();
  await page.screenshot({ path: 'screenshots/login-failed.png', fullPage: true });
});
