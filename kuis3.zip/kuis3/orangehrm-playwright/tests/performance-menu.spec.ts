import { test, expect } from '@playwright/test';
import { login } from '../helpers/helpers';
import fs from 'fs';

fs.mkdirSync('screenshots', { recursive: true });

test('Navigasi ke menu Performance', async ({ page }) => {
  // Step 1: Login
  await login(page);

  // Step 2: Klik menu Performance
  const performanceMenu = page.getByRole('link', { name: 'Performance' });
  await expect(performanceMenu).toBeVisible({ timeout: 5000 });
  await performanceMenu.click();

  // Step 3: Verifikasi heading Performance
  const heading = page.locator('h6', { hasText: 'Performance' });
  await expect(heading).toBeVisible({ timeout: 5000 });

  // Step 4: Screenshot
  await page.screenshot({ path: 'screenshots/performance-menu.png', fullPage: true });
});
