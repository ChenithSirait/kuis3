import { test, expect } from '@playwright/test';
import { login } from '../helpers/helpers';
import fs from 'fs';

fs.mkdirSync('screenshots', { recursive: true });

test('Navigasi ke menu Leave', async ({ page }) => {
  await login(page);

  await page.getByRole('link', { name: 'Leave' }).click();

  // Perbaikan: heading ternyata <h5>, bukan <h6>
  await expect(page.getByRole('heading', { name: 'Leave List', level: 5 })).toBeVisible({ timeout: 5000 });

  await page.screenshot({ path: 'screenshots/navigate-leave.png', fullPage: true });
});
