import { test, expect } from '@playwright/test';
import { login } from '../helpers/helpers';
import fs from 'fs';

// Pastikan folder screenshots tersedia
fs.mkdirSync('screenshots', { recursive: true });

test('Cek apakah user profile picture muncul', async ({ page }) => {
  // Login terlebih dahulu
  await login(page);

  // Cari elemen gambar profil di pojok kanan atas
  const profileImage = page.getByRole('img', { name: /profile picture/i });

  // Pastikan elemen gambar terlihat
  await expect(profileImage).toBeVisible({ timeout: 5000 });

  // Ambil screenshot bukti profil muncul
  await page.screenshot({ path: 'screenshots/user-profile.png', fullPage: true });
});
