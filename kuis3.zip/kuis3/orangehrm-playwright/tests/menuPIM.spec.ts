import { test, expect } from '@playwright/test';
import { login } from '../helpers/helpers';
import fs from 'fs';

// Buat folder screenshots jika belum ada
fs.mkdirSync('screenshots', { recursive: true });

test('Verifikasi menu PIM bisa diklik dan halaman terbuka', async ({ page }) => {
  // Login ke aplikasi
  await login(page);

  // Klik menu PIM
  const pimMenu = page.getByRole('link', { name: 'PIM' });
  await expect(pimMenu).toBeVisible({ timeout: 10000 });
  await pimMenu.click();

  // Tunggu network idle
  await page.waitForLoadState('networkidle');

  // Coba cari heading atau elemen unik di halaman PIM
  const possibleHeadings = [
    'Employee Information',
    'PIM',
    'Employee List',
    'Personal Details'
  ];

  let found = false;
  for (const headingText of possibleHeadings) {
    const heading = page.locator('h6', { hasText: headingText });
    if (await heading.count()) {
      await expect(heading).toBeVisible({ timeout: 5000 });
      found = true;
      break;
    }
  }

  // Kalau tidak ada heading yang ditemukan, fail test dengan pesan jelas
  expect(found).toBeTruthy();

  // Screenshot halaman PIM
  await page.screenshot({ path: 'screenshots/pim-page.png', fullPage: true });
});
